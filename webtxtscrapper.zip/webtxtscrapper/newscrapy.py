import bs4 as bs
import urllib.request

sauce = urllib.request.urlopen('https://www.facebook.com/notes/nigeriana-news/must-read-for-every-nigerian-latest-message-from-the-boko-haram-leader-abubakar-/662596830442942/').read()
soup = bs.BeautifulSoup(sauce,'lxml')



for mul_tags in soup.find_all(['p','h1','h3']):
     print(mul_tags.string)